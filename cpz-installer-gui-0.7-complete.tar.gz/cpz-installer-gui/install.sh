#!/bin/sh
set -eu
BASE=/usr/share/APPLaunch
sudo install -d "$BASE/bin" "$BASE/applications" "$BASE/share/images"
sudo install -m 755 cpz-installer-ui "$BASE/bin/cpz-installer-ui"
sudo install -m 755 scripts/run-cpz-installer "$BASE/bin/run-cpz-installer"
sudo install -m 755 src/cpz-installer-core.py "$BASE/bin/cpz-installer-core.py"
sudo install -m 644 assets/applications/cpz-installer.desktop "$BASE/applications/cpz-installer.desktop"
sudo install -m 644 assets/images/cpz-installer.png "$BASE/share/images/cpz-installer.png"
echo Installed
