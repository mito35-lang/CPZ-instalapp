# CPZ Installer 0.4 — проект для CardputerZero

## Назначение

CPZ Installer — файловый установщик приложений для CardputerZero с графическим интерфейсом на экране 320×170. Проводник открывает папку `/home/mito/projects`, позволяет перемещаться по каталогам, выбирать архивы, проверять их и запускать установку.

Проект разделён на два компонента:

- `src/installer_ui.cpp` — нативный C++ интерфейс framebuffer и обработка клавиатуры Linux input events.
- `src/cpz-installer-core.py` — ядро проверки, распаковки, сборки, установки и удаления пакетов.

## Поддерживаемые пакеты

Поддерживаются архивы `.tar`, `.tar.gz`, `.tgz`, `.tar.xz`, `.tar.bz2`, `.zip` и пакеты `.deb`. Исходники с `Makefile` собираются на CardputerZero; готовые приложения и desktop-файлы устанавливаются в `APPLaunch`.

Проверяются целостность архива, CRC ZIP, опасные пути вроде `../../`, символьные ссылки и контрольная сумма SHA-256.

## Установка на устройство

Архив проекта нужно положить в:

```text
/home/mito/projects/cpz-installer-gui-0.4-complete.tar.gz
```

Затем в PuTTY выполнить:

```bash
cd /home/mito/projects && rm -rf cpz-installer-gui && tar -xzf cpz-installer-gui-0.4-complete.tar.gz && cd cpz-installer-gui && make && sudo ./install.sh
```

После сборки в меню `APPLaunch` появится пункт `CPZ Installer`.

Ручной запуск:

```bash
sudo /usr/share/APPLaunch/bin/run-cpz-installer /home/mito/projects
```

## Управление

- `F` или `K` — вверх;
- `X` или `J` — вниз;
- `Enter` — открыть каталог или установить выбранный архив;
- `Esc` — вернуться на уровень вверх или выйти из проводника;
- `I` — показать информацию и проверить выбранный архив;
- `U` — показать список установленных пакетов.

Стрелки `KEY_UP` и `KEY_DOWN` также обрабатываются, если конкретная прошивка передаёт их как обычные Linux input events.

## Удаление

Список установленных пакетов:

```bash
sudo python3 /usr/share/APPLaunch/bin/cpz-installer-core.py list
```

Удаление по ID пакета:

```bash
sudo python3 /usr/share/APPLaunch/bin/cpz-installer-core.py uninstall PACKAGE_ID
```

## Пути установки

- UI: `/usr/share/APPLaunch/bin/cpz-installer-ui`
- launcher: `/usr/share/APPLaunch/bin/run-cpz-installer`
- Core: `/usr/share/APPLaunch/bin/cpz-installer-core.py`
- desktop-файл: `/usr/share/APPLaunch/applications/cpz-installer.desktop`
- иконка: `/usr/share/APPLaunch/share/images/cpz-installer.png`
- база установленных пакетов: `/var/lib/cpz-installer/packages`

## Сборка

Сборка выполняется непосредственно на CardputerZero, чтобы бинарник соответствовал архитектуре устройства:

```bash
make
sudo ./install.sh
```

Для сборки нужны `g++`, `make` и `python3`:

```bash
sudo apt-get update
sudo apt-get install -y g++ make python3
```

## Диагностика

Проверка экрана:

```bash
cat /proc/fb
fbset -fb /dev/fb_lcd -i
```

Ожидаемый режим:

```text
320x170
16 bit
LineLength 640
```

Проверка файлов проекта:

```bash
ls -l /usr/share/APPLaunch/bin/cpz-installer*
ls -l /usr/share/APPLaunch/applications/cpz-installer.desktop
ls -l /usr/share/APPLaunch/share/images/cpz-installer.png
```

Если PuTTY закрывается, не запускай UI в той же команде установки. Сначала выполни `make` и `sudo ./install.sh`, затем запускай CPZ Installer из меню `APPLaunch`.
