#!/usr/bin/env python3
"""CPZ Installer - a cautious package installer for CardputerZero/Linux.

Supports tar/tar.gz/tar.xz/tar.bz2, zip, and deb packages; source trees,
prebuilt binaries, desktop entries, and an optional cpz-manifest.json.
"""
from __future__ import annotations
import argparse, configparser, hashlib, json, os, platform, re, shutil, subprocess, sys, tempfile, textwrap, time
from pathlib import Path

APP = "CPZ Installer"
DB_DIR = Path(os.environ.get("CPZ_DB_DIR", "/var/lib/cpz-installer"))
PKG_DB = DB_DIR / "packages"
DEFAULT_ROOT = Path("/usr/share/APPLaunch")
SAFE_ROOTS = [Path("/usr/share/APPLaunch"), Path("/usr/local/bin"), Path.home() / ".local"]
ARCHIVES = {".tar.gz", ".tgz", ".tar", ".tar.xz", ".txz", ".tar.bz2", ".tbz2", ".zip", ".deb"}

class InstallError(Exception): pass

def is_root(): return os.geteuid() == 0

def run(cmd, cwd=None, check=True, capture=False, env=None):
    return subprocess.run(cmd, cwd=cwd, check=check, text=True, capture_output=capture, env=env)

def sudo_prefix(): return [] if is_root() else ["sudo"]

def elevated(cmd, **kw): return run(sudo_prefix() + cmd, **kw)

def archive_type(p: Path):
    n = p.name.lower()
    if n.endswith(".tar.gz") or n.endswith(".tgz"): return "tar.gz"
    if n.endswith(".tar.xz") or n.endswith(".txz"): return "tar.xz"
    if n.endswith(".tar.bz2") or n.endswith(".tbz2"): return "tar.bz2"
    if n.endswith(".tar"): return "tar"
    if n.endswith(".zip"): return "zip"
    if n.endswith(".deb"): return "deb"
    return None

def sha256(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()

def safe_member(name: str):
    # Archives must never escape the temporary extraction directory.
    q = name.replace("\\", "/")
    if q.startswith("/") or re.match(r"^[A-Za-z]:", q): return False
    parts = [x for x in q.split("/") if x not in ("", ".")]
    return ".." not in parts

def validate_archive(p: Path):
    kind = archive_type(p)
    if not kind: raise InstallError("Неподдерживаемый формат архива")
    if p.stat().st_size == 0: raise InstallError("Пустой архив")
    if kind == "deb":
        r = run(["dpkg-deb", "--info", str(p)], check=False, capture=True)
        if r.returncode: raise InstallError("Файл не является корректным .deb: " + r.stderr.strip())
        return {"type": kind, "members": []}
    if kind == "zip":
        import zipfile
        with zipfile.ZipFile(p) as z:
            bad = z.testzip()
            if bad: raise InstallError("Повреждённый ZIP-файл: " + bad)
            names = z.namelist()
    else:
        import tarfile
        mode = {"tar.gz":"r:gz", "tar.xz":"r:xz", "tar.bz2":"r:bz2", "tar":"r"}[kind]
        with tarfile.open(p, mode) as t:
            names = t.getnames()
            if not all(safe_member(x) for x in names): raise InstallError("Архив содержит опасный путь")
            for m in t.getmembers():
                if m.issym() or m.islnk():
                    target = Path(m.name).parent / m.linkname
                    if not safe_member(str(target)):
                        raise InstallError("Архив содержит небезопасную ссылку: " + m.name)
    if not all(safe_member(x) for x in names): raise InstallError("Архив содержит опасный путь")
    return {"type": kind, "members": names}

def extract(p: Path, dest: Path):
    info = validate_archive(p)
    if info["type"] == "deb": return dest
    dest.mkdir(parents=True, exist_ok=True)
    if info["type"] == "zip":
        import zipfile
        with zipfile.ZipFile(p) as z: z.extractall(dest)
    else:
        import tarfile
        mode = {"tar.gz":"r:gz", "tar.xz":"r:xz", "tar.bz2":"r:bz2", "tar":"r"}[info["type"]]
        with tarfile.open(p, mode) as t: t.extractall(dest)
    return dest

def top_dir(root: Path):
    items = [x for x in root.iterdir()]
    return items[0] if len(items) == 1 and items[0].is_dir() else root

def read_manifest(root: Path):
    candidates = list(root.rglob("cpz-manifest.json")) + list(root.rglob("manifest.json"))
    for p in candidates[:1]:
        try: return json.loads(p.read_text(encoding="utf-8")), p.parent
        except Exception as e: raise InstallError(f"Ошибка манифеста: {e}")
    for p in list(root.rglob("manifest.ini"))[:1]:
        c = configparser.ConfigParser(); c.read(p, encoding="utf-8")
        if c.has_section("package"): return dict(c["package"]), p.parent
    return {}, top_dir(root)

def detect(root: Path, archive: Path):
    manifest, base = read_manifest(root)
    desktops = list(base.rglob("*.desktop"))
    desktop_name = ""
    for desktop in desktops[:1]:
        try:
            for line in desktop.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.startswith("Name="):
                    desktop_name = line.split("=", 1)[1].strip()
                    break
        except OSError:
            pass
    name = manifest.get("name") or desktop_name or base.name
    version_match = re.search(r"(?:^|[-_])v?(\d+\.\d+(?:\.\d+)+)(?:[-_.]|$)", archive.name)
    version = manifest.get("version") or (version_match.group(1) if version_match else "unknown")
    typ = manifest.get("type", "")
    make = (base / "Makefile").exists() or (base / "makefile").exists()
    cmake = (base / "CMakeLists.txt").exists()
    install_script = next((base / x for x in ("INSTALL.sh", "install.sh") if (base / x).exists()), None)
    deb = archive.suffix == ".deb"
    binaries = [x for x in base.rglob("*") if x.is_file() and os.access(x, os.X_OK) and not x.name.endswith((".sh", ".py"))]
    if deb: typ = "deb"
    elif not typ: typ = "source" if (make or cmake or install_script) else ("binary" if binaries else "resources")
    return {"name": str(name), "version": str(version), "type": typ, "base": base, "manifest": manifest,
            "make": make, "cmake": cmake, "install_script": install_script, "binaries": binaries, "desktops": desktops}

def norm_rel(p: Path): return str(p.relative_to(p.anchor)) if p.is_absolute() else str(p)

def ensure_inside(path: Path, roots=SAFE_ROOTS):
    path = path.resolve()
    return any(path == r.resolve() or r.resolve() in path.parents for r in roots)

def copy_tree_staged(stage: Path, record):
    files = []
    for src in stage.rglob("*"):
        if not src.is_file(): continue
        rel = src.relative_to(stage)
        dst = Path("/") / rel
        if not ensure_inside(dst): raise InstallError("Установка за пределы разрешённых каталогов: " + str(dst))
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            backup = DB_DIR / "backups" / record["id"] / str(rel)
            backup.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(dst, backup); record.setdefault("backups", []).append(str(backup))
        shutil.copy2(src, dst); files.append(str(dst))
        if os.access(src, os.X_OK): dst.chmod(dst.stat().st_mode | 0o111)
    return files

def install_deb(archive, meta, record):
    if not shutil.which("dpkg"): raise InstallError("dpkg не найден")
    if not is_root(): raise InstallError("Для .deb запусти установщик через sudo")
    run(["dpkg", "-i", str(archive)])
    q = run(["dpkg-query", "-W", "-f=${Package}\\n", meta["manifest"].get("package", "")], check=False, capture=True)
    record["dpkg_package"] = meta["manifest"].get("package", "")
    return []

def install_package(archive: Path, allow_scripts=False):
    info = validate_archive(archive)
    if info["type"] == "deb":
        with tempfile.TemporaryDirectory() as td:
            r = run(["dpkg-deb", "-f", str(archive), "Package", "Version"], capture=True)
            vals = r.stdout.splitlines(); meta = {"name": vals[0] if vals else archive.stem, "version": vals[1] if len(vals)>1 else "unknown", "manifest": {"package": vals[0] if vals else ""}}
            rec = {"id": re.sub(r"[^a-zA-Z0-9_.-]", "-", meta["name"]), "name": meta["name"], "version": meta["version"], "archive": str(archive), "type":"deb", "installed_at":time.time()}
            install_deb(archive, meta, rec); return rec
    with tempfile.TemporaryDirectory(prefix="cpz-verify-") as td:
        root = Path(td); extract(archive, root); meta = detect(root, archive)
        rec = {"id": re.sub(r"[^a-zA-Z0-9_.-]", "-", meta["name"]), "name":meta["name"], "version":meta["version"], "archive":str(archive), "type":meta["type"], "installed_at":time.time(), "files":[]}
        if meta["type"] == "source":
            if meta["install_script"] and not (meta["make"] or meta["cmake"]) and not allow_scripts:
                raise InstallError("Найден INSTALL.sh. Повтори с --allow-scripts после проверки скрипта")
            build = meta["base"]
            if meta["make"]:
                run(["make", "-j1"], cwd=build)
                stage = root / ".cpz-stage"; stage.mkdir()
                run(["make", "DESTDIR=" + str(stage), "install"], cwd=build)
                rec["files"] = copy_tree_staged(stage, rec)
            elif meta["cmake"]:
                b = root / ".cpz-build"; stage = root / ".cpz-stage"; b.mkdir(); stage.mkdir()
                run(["cmake", "-S", str(build), "-B", str(b), "-DCMAKE_INSTALL_PREFIX=/usr/share/APPLaunch", "-DCMAKE_INSTALL_LIBDIR=lib"])
                run(["cmake", "--build", str(b), "-j1"])
                env = os.environ.copy(); env["DESTDIR"] = str(stage)
                run(["cmake", "--install", str(b), "--prefix", "/usr/share/APPLaunch", "--strip"], env=env)
                rec["files"] = copy_tree_staged(stage, rec)
            else: raise InstallError("Исходники не содержат поддерживаемой Makefile-схемы")
        elif meta["type"] == "binary":
            target = Path("/usr/share/APPLaunch/bin"); target.mkdir(parents=True, exist_ok=True)
            for b in meta["binaries"]:
                dst = target / b.name; shutil.copy2(b, dst); dst.chmod(0o755); rec["files"].append(str(dst))
            for d in meta["desktops"]:
                dst = Path("/usr/share/APPLaunch/applications") / d.name; dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(d, dst); rec["files"].append(str(dst))
        else:
            raise InstallError("Не удалось безопасно определить способ установки. Нужен cpz-manifest.json")
        PKG_DB.mkdir(parents=True, exist_ok=True); (PKG_DB / (rec["id"] + ".json")).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
        return rec

def uninstall(pkgid):
    p = PKG_DB / (pkgid if pkgid.endswith(".json") else pkgid + ".json")
    if not p.exists(): raise InstallError("Пакет не найден: " + pkgid)
    rec = json.loads(p.read_text(encoding="utf-8"))
    if rec.get("type") == "deb" and rec.get("dpkg_package"):
        if not is_root(): raise InstallError("Для удаления .deb запусти через sudo")
        run(["dpkg", "-r", rec["dpkg_package"]])
    for f in rec.get("files", []):
        q = Path(f)
        if ensure_inside(q) and q.is_file(): q.unlink()
    for b in rec.get("backups", []):
        src = Path(b); original = Path("/") / src.relative_to(DB_DIR / "backups" / rec["id"])
        if src.exists(): original.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(src, original)
    p.unlink()

def packages():
    if not PKG_DB.exists(): return []
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(PKG_DB.glob("*.json"))]

def inspect(path):
    p = Path(path).expanduser(); info = validate_archive(p)
    print(f"Файл: {p}\nРазмер: {p.stat().st_size} байт\nТип: {info['type']}\nSHA-256: {sha256(p)}")
    if info["type"] != "deb":
        with tempfile.TemporaryDirectory() as td:
            extract(p, Path(td)); m = detect(Path(td), p)
            print(f"Распознавание: {m['type']}\nНазвание: {m['name']}\nВерсия: {m['version']}")

def tui(folder):
    # Simple keyboard UI usable over a serial/terminal session.
    while True:
        files = sorted([p for p in Path(folder).expanduser().iterdir() if p.is_file() and archive_type(p)])
        print("\n=== CPZ Installer ===")
        print("Папка:", Path(folder).expanduser())
        for i,p in enumerate(files,1): print(f" {i}. {p.name}")
        print(" i) установленные   u) удалить   q) выход")
        choice = input("> ").strip()
        if choice.lower() == "q": return
        if choice.lower() == "i":
            for x in packages(): print(f"{x['id']}  {x['name']} {x['version']} ({x['type']})")
            continue
        if choice.lower() == "u":
            for x in packages(): print(f"{x['id']}  {x['name']} {x['version']}")
            try: uninstall(input("ID для удаления: ").strip()); print("Удалено")
            except Exception as e: print("Ошибка:", e)
            continue
        try:
            p = files[int(choice)-1]; inspect(p)
            if input("Установить? [y/N] ").lower() == "y":
                r=install_package(p); print("Установлено:", r["name"], r["version"])
        except Exception as e: print("Ошибка:", e)

def main():
    ap=argparse.ArgumentParser(description=APP)
    sub=ap.add_subparsers(dest="cmd")
    x=sub.add_parser("inspect"); x.add_argument("archive")
    x=sub.add_parser("install"); x.add_argument("archive"); x.add_argument("--allow-scripts", action="store_true")
    x=sub.add_parser("uninstall"); x.add_argument("package")
    sub.add_parser("list")
    x=sub.add_parser("browse"); x.add_argument("folder", nargs="?", default="/mnt/SDCARD")
    a=ap.parse_args()
    try:
        if a.cmd == "inspect": inspect(a.archive)
        elif a.cmd == "install": print(json.dumps(install_package(Path(a.archive).expanduser(), a.allow_scripts), ensure_ascii=False, indent=2))
        elif a.cmd == "uninstall": uninstall(a.package); print("Удалено")
        elif a.cmd == "list":
            for p in packages(): print(f"{p['id']}\t{p['name']}\t{p['version']}\t{p['type']}")
        else: tui(a.folder)
    except (InstallError, subprocess.CalledProcessError) as e: print("Ошибка:", e, file=sys.stderr); return 1
    return 0
if __name__ == "__main__": sys.exit(main())
