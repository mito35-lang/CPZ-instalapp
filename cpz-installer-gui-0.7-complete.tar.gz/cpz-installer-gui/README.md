# CPZ Installer 0.2

Графическая версия для CardputerZero: отдельное C++ UI на framebuffer и Python core для проверки/установки/удаления пакетов.

## Сборка и установка

```bash
make
sudo ./install.sh
```

Запуск вручную:

```bash
/usr/share/APPLaunch/bin/run-cpz-installer /home/mito/projects
```

По умолчанию проводник открывает `/home/mito/projects` — папку для архивов.

## Навигация

`UP/DOWN` — выбор, `ENTER` — войти в папку или установить архив, `ESC` — назад/выход, `I` — информация об архиве, `U` — список установленных пакетов.

## Архитектура

- `src/installer_ui.cpp` — framebuffer 320x170, клавиатура Linux input events, проводник.
- `src/cpz-installer-core.py` — проверка архивов, распаковка, Make/CMake, бинарники, deb, журнал и uninstall.
- `assets/applications/cpz-installer.desktop` — иконка запуска APPLaunch.
